
 function changeTop_del1() {
  
    window.webkit.messageHandlers.AppModel.postMessage({body: 'adasdadas'});

 }
function aaaa() {
    
    window.webkit.messageHandlers.AppModel.postMessage({body: 'qqqqqqqqqqqq'});
    
}
